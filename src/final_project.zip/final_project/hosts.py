class Host:
    def __init__(self, host_id, place, city, profits=0):
        self.host_id = host_id
        self.city = city
        self.profits = profits
        # Determine the host area according to its initial place
        self.area = place.area
        # Group of properties
        self.assets = {place.place_id}

    def update_profits(self):
        for place_id in self.assets:
            place = self.city.places[place_id]  # obtener Place del diccionario de la City
            self.profits += place.rate * place.occupancy

    def make_bids(self, modified_rule=False):
    bids = []
    # 1. Finding opportunities (properties adjacent to assets)
    opportunities = set()
    for place_id in self.assets:
        place = self.city.places[place_id]
        for n in place.neighbours:
            if n not in self.assets:
                opportunities.add(n)
    # 2. Create the bids
    for pid in opportunities:
        place = self.city.places[pid]
        # Actual price (the most recent entry)
        ask_price = list(place.price.values())[-1]
        # Modified rule for graph2_v1
        if modified_rule:
            # Only bid if the property's rate is less than the area average
            area_avg = self.city.area_average_rate(place.area)
            if place.rate >= area_avg:
                continue
        # Check if the host has enough profits to buy it
        if self.profits >= ask_price:
            bid = {
                'place_id': pid,
                'seller_id': place.host_id,
                'buyer_id': self.host_id,
                'spread': self.profits - ask_price,
                'bid_price': self.profits
            }
            bids.append(bid)

    return bids
