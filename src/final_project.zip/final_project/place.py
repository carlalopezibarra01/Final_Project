import random
class Place:
    def __init__ (self, place_id, host_id, city):
        self.place_id= place_id
        self.host_id= host_id
        self.city= city
        # Attributes that will be filled with setup()
        self.neighbours = []
        self.area = None
        self.rate = None
        self.price = {}
        self.occupancy = 0
        # Initialize attributes
        self.setup()
    
    def setup(self):
        # 1. Neighbours: IDs from adjacent places
        self.neighbours = self.city.get_adjacent_places(self.place_id)
        # 2. Area where it belongs
        self.area = self.city.get_area_for_place(self.place_id)
        # 3. Rate: Price per night within the range assigned to the area
        min_rate, max_rate = self.city.area_rates[self.area]
        self.rate = random.uniform(min_rate, max_rate)
        # 4. Price history
        self.price = {0: 900 * self.rate}

     def update_occupancy(self):
        # Compute average prices in the area
        area_avg = self.city.get_mean_rate(self.area)

        if self.rate > area_avg:
            # Demand falls when prices rise
            self.occupancy = random.randint(5, 15)
        else:
            # Higher demand for lower prices:
            self.occupancy = random.randint(10, 20)