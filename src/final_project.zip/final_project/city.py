import pandas as pd
from .place import Place
from .host import Host
import random

class City:
    def __init__(self, size, area_rates):
        self.size = size
        self.area_rates = area_rates
        self.step = 0
        # Dictionaries to store hosts and places
        self.places = {}
        self.hosts = {}

    # Initialize: Create all "Place" and "Host"
    def initialize(self, modified_rule=False):
        self.modified_rule = modified_rule
        self.places = {}
        self.hosts = {}
        place_id = 0
        # Create one Place for each cell in the grid
        for row in range(self.size):
            for col in range(self.size):
                host_id = place_id  # every initial place belongs to a different host
                # Create the place
                place = Place(place_id=place_id, host_id=host_id, city=self)
                place.setup()  # IMPORTANT
                # Create the host
                host = Host(host_id=host_id, place=place, city=self)
                # Store them
                self.places[place_id] = place
                self.hosts[host_id] = host
                place_id += 1

    # Necessary methods for Place
    def get_adjacent_places(self, place_id):
        row = place_id // self.size
        col = place_id % self.size
        neighbours = []
        # 8 possible directions
        directions = [
            (-1, -1), (-1, 0), (-1, 1),
            (0, -1),          (0, 1),
            (1, -1), (1, 0),  (1, 1)
        ]
        for dr, dc in directions:
            r = row + dr
            c = col + dc
            if 0 <= r < self.size and 0 <= c < self.size:
                neighbours.append(r * self.size + c)
        return neighbours

    def get_area_for_place(self, place_id):
        row = place_id // self.size
        col = place_id % self.size
        mid = self.size // 2
        if row < mid and col < mid:
            return 0  # bottom-left
        elif row < mid and col >= mid:
            return 1  # bottom-right
        elif row >= mid and col < mid:
            return 2  # top-left
        else:
            return 3  # top-right

    def get_mean_rate(self, area):
        # average rate in one area
        rates = [p.rate for p in self.places.values() if p.area == area]
        return sum(rates) / len(rates)
    
    # Necessary method for graph 2
    def avg_rates(self):
    averages = {}
    for area in [0, 1, 2, 3]:
        averages[area] = self.get_mean_rate(area)
    return averages


    # Approve bids
    def approve_bids(self, bids):
        if len(bids) == 0:
            return []
        df = pd.DataFrame(bids)
        df = df.sort_values(by='spread', ascending=False)
        approved = []
        bought_by = set()
        sold_places = set()
        for _, bid in df.iterrows():
            pid = bid['place_id']
            buyer = bid['buyer_id']
            seller = bid['seller_id']
            if buyer in bought_by:  
                continue
            if pid in sold_places:
                continue
            approved.append(bid.to_dict())
            bought_by.add(buyer)
            sold_places.add(pid)
        return approved

    # Execute transactions
    def execute_transactions(self, transactions):
        for t in transactions:
            pid = t['place_id']
            buyer_id = t['buyer_id']
            seller_id = t['seller_id']
            price = t['bid_price']
            buyer = self.hosts[buyer_id]
            seller = self.hosts[seller_id]
            place = self.places[pid]
            buyer.profits -= price
            seller.profits += price
            seller.assets.remove(pid)
            buyer.assets.add(pid)
            place.host_id = buyer_id
            place.price[self.step] = price
        return transactions

    # Clear market: execution of approved bids
    def clear_market(self):
        all_bids = []
        for host in self.hosts.values():
            all_bids.extend(host.make_bids())
        if len(all_bids) == 0:
            return []
        approved = self.approve_bids(all_bids)
        executed = self.execute_transactions(approved)
        return executed

    # Iterate
    def iterate(self):
        self.step += 1
        for place in self.places.values():
            place.update_occupancy()
        for host in self.hosts.values():
            host.update_profits()
        transactions = self.clear_market()
        # Necessary for graph 2
        return transactions, self.avg_rates()

